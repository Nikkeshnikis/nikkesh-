/**
 * Created by LzxHahaha on 2016/10/6.
 */

module.exports = require('./dist/Game');
